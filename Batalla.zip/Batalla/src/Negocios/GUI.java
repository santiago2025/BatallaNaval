/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Negocios;

/**
 *
 * @author DAVID
 */
public class GUI extends javax.swing.JFrame {

    /**
     * Creates new form GUI
     */
    public GUI() {
        initComponents();
    }

       public static void main(String args[]) {
       GUI g = new GUI();
       g.setTitle("Batalla Naval");
       g.setBounds(300, 0, 618, 642);
       g.setVisible(true);
       
    }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton102 = new javax.swing.JButton();
        jButton81 = new javax.swing.JButton();
        jButton85 = new javax.swing.JButton();
        jButton97 = new javax.swing.JButton();
        jButton95 = new javax.swing.JButton();
        jButton87 = new javax.swing.JButton();
        jButton89 = new javax.swing.JButton();
        jButton93 = new javax.swing.JButton();
        jButton96 = new javax.swing.JButton();
        jButton79 = new javax.swing.JButton();
        jButton76 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jButton83 = new javax.swing.JButton();
        jButton100 = new javax.swing.JButton();
        jButton82 = new javax.swing.JButton();
        jButton84 = new javax.swing.JButton();
        jButton88 = new javax.swing.JButton();
        jButton101 = new javax.swing.JButton();
        jButton94 = new javax.swing.JButton();
        jButton86 = new javax.swing.JButton();
        jButton92 = new javax.swing.JButton();
        jButton91 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jButton98 = new javax.swing.JButton();
        jButton78 = new javax.swing.JButton();
        jButton90 = new javax.swing.JButton();
        jButton77 = new javax.swing.JButton();
        jButton80 = new javax.swing.JButton();
        jButton99 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jButton138 = new javax.swing.JButton();
        jButton139 = new javax.swing.JButton();
        jButton140 = new javax.swing.JButton();
        jButton141 = new javax.swing.JButton();
        jButton142 = new javax.swing.JButton();
        jButton143 = new javax.swing.JButton();
        jButton144 = new javax.swing.JButton();
        jButton145 = new javax.swing.JButton();
        jButton146 = new javax.swing.JButton();
        jButton147 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jButton3 = new javax.swing.JButton();
        jButton13 = new javax.swing.JButton();
        jButton14 = new javax.swing.JButton();
        jButton15 = new javax.swing.JButton();
        jButton16 = new javax.swing.JButton();
        jButton17 = new javax.swing.JButton();
        jButton18 = new javax.swing.JButton();
        jButton19 = new javax.swing.JButton();
        jButton20 = new javax.swing.JButton();
        jButton21 = new javax.swing.JButton();
        jButton22 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton23 = new javax.swing.JButton();
        jButton24 = new javax.swing.JButton();
        jButton25 = new javax.swing.JButton();
        jButton26 = new javax.swing.JButton();
        jButton27 = new javax.swing.JButton();
        jButton28 = new javax.swing.JButton();
        jButton29 = new javax.swing.JButton();
        jButton30 = new javax.swing.JButton();
        jButton31 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton32 = new javax.swing.JButton();
        jButton33 = new javax.swing.JButton();
        jButton34 = new javax.swing.JButton();
        jButton35 = new javax.swing.JButton();
        jButton36 = new javax.swing.JButton();
        jButton37 = new javax.swing.JButton();
        jButton38 = new javax.swing.JButton();
        jButton39 = new javax.swing.JButton();
        jButton40 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton41 = new javax.swing.JButton();
        jButton42 = new javax.swing.JButton();
        jButton43 = new javax.swing.JButton();
        jButton44 = new javax.swing.JButton();
        jButton45 = new javax.swing.JButton();
        jButton46 = new javax.swing.JButton();
        jButton47 = new javax.swing.JButton();
        jButton48 = new javax.swing.JButton();
        jButton49 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton50 = new javax.swing.JButton();
        jButton51 = new javax.swing.JButton();
        jButton52 = new javax.swing.JButton();
        jButton53 = new javax.swing.JButton();
        jButton54 = new javax.swing.JButton();
        jButton55 = new javax.swing.JButton();
        jButton56 = new javax.swing.JButton();
        jButton57 = new javax.swing.JButton();
        jButton58 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton59 = new javax.swing.JButton();
        jButton60 = new javax.swing.JButton();
        jButton61 = new javax.swing.JButton();
        jButton62 = new javax.swing.JButton();
        jButton63 = new javax.swing.JButton();
        jButton64 = new javax.swing.JButton();
        jButton65 = new javax.swing.JButton();
        jButton66 = new javax.swing.JButton();
        jButton67 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton68 = new javax.swing.JButton();
        jButton69 = new javax.swing.JButton();
        jButton70 = new javax.swing.JButton();
        jButton71 = new javax.swing.JButton();
        jButton72 = new javax.swing.JButton();
        jButton73 = new javax.swing.JButton();
        jButton74 = new javax.swing.JButton();
        jButton75 = new javax.swing.JButton();
        jButton103 = new javax.swing.JButton();
        jButton112 = new javax.swing.JButton();
        jButton110 = new javax.swing.JButton();
        jButton108 = new javax.swing.JButton();
        jButton109 = new javax.swing.JButton();
        jButton107 = new javax.swing.JButton();
        jButton104 = new javax.swing.JButton();
        jButton105 = new javax.swing.JButton();
        jButton106 = new javax.swing.JButton();
        jButton111 = new javax.swing.JButton();
        jButton113 = new javax.swing.JButton();
        jButton114 = new javax.swing.JButton();
        jButton115 = new javax.swing.JButton();
        jButton116 = new javax.swing.JButton();
        jButton117 = new javax.swing.JButton();
        jButton118 = new javax.swing.JButton();
        jButton119 = new javax.swing.JButton();
        jButton120 = new javax.swing.JButton();
        jButton121 = new javax.swing.JButton();
        jButton122 = new javax.swing.JButton();
        jButton123 = new javax.swing.JButton();
        jButton124 = new javax.swing.JButton();
        jButton125 = new javax.swing.JButton();
        jButton126 = new javax.swing.JButton();
        jButton127 = new javax.swing.JButton();
        jButton128 = new javax.swing.JButton();
        jButton129 = new javax.swing.JButton();
        jButton130 = new javax.swing.JButton();
        jButton131 = new javax.swing.JButton();
        jButton132 = new javax.swing.JButton();
        jButton133 = new javax.swing.JButton();
        jButton134 = new javax.swing.JButton();
        jButton135 = new javax.swing.JButton();
        jButton136 = new javax.swing.JButton();
        jButton137 = new javax.swing.JButton();
        jButton148 = new javax.swing.JButton();
        jButton149 = new javax.swing.JButton();
        jButton150 = new javax.swing.JButton();
        jButton151 = new javax.swing.JButton();
        jButton152 = new javax.swing.JButton();
        jButton153 = new javax.swing.JButton();
        jButton154 = new javax.swing.JButton();
        jButton155 = new javax.swing.JButton();
        jButton156 = new javax.swing.JButton();
        jButton157 = new javax.swing.JButton();

        jButton102.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton102.setText("jButton3");
        jButton102.setContentAreaFilled(false);
        jButton102.setFocusPainted(false);
        jButton102.setMaximumSize(new java.awt.Dimension(70, 70));

        jButton81.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton81.setText("jButton3");
        jButton81.setContentAreaFilled(false);
        jButton81.setFocusPainted(false);
        jButton81.setMaximumSize(new java.awt.Dimension(70, 70));

        jButton85.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton85.setText("jButton3");
        jButton85.setContentAreaFilled(false);
        jButton85.setFocusPainted(false);
        jButton85.setMaximumSize(new java.awt.Dimension(70, 70));

        jButton97.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton97.setText("jButton3");
        jButton97.setContentAreaFilled(false);
        jButton97.setFocusPainted(false);
        jButton97.setMaximumSize(new java.awt.Dimension(70, 70));

        jButton95.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton95.setText("jButton3");
        jButton95.setContentAreaFilled(false);
        jButton95.setFocusPainted(false);
        jButton95.setMaximumSize(new java.awt.Dimension(70, 70));

        jButton87.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton87.setText("jButton3");
        jButton87.setContentAreaFilled(false);
        jButton87.setFocusPainted(false);
        jButton87.setMaximumSize(new java.awt.Dimension(70, 70));

        jButton89.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton89.setText("jButton3");
        jButton89.setContentAreaFilled(false);
        jButton89.setFocusPainted(false);
        jButton89.setMaximumSize(new java.awt.Dimension(70, 70));

        jButton93.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton93.setText("jButton3");
        jButton93.setContentAreaFilled(false);
        jButton93.setFocusPainted(false);
        jButton93.setMaximumSize(new java.awt.Dimension(70, 70));

        jButton96.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton96.setText("jButton3");
        jButton96.setContentAreaFilled(false);
        jButton96.setFocusPainted(false);
        jButton96.setMaximumSize(new java.awt.Dimension(70, 70));

        jButton79.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton79.setText("jButton3");
        jButton79.setContentAreaFilled(false);
        jButton79.setFocusPainted(false);
        jButton79.setMaximumSize(new java.awt.Dimension(70, 70));

        jButton76.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton76.setText("jButton3");
        jButton76.setContentAreaFilled(false);
        jButton76.setFocusPainted(false);
        jButton76.setMaximumSize(new java.awt.Dimension(70, 70));

        jButton12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton12.setText("jButton3");
        jButton12.setContentAreaFilled(false);
        jButton12.setFocusPainted(false);
        jButton12.setMaximumSize(new java.awt.Dimension(70, 70));

        jButton83.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton83.setText("jButton3");
        jButton83.setContentAreaFilled(false);
        jButton83.setFocusPainted(false);
        jButton83.setMaximumSize(new java.awt.Dimension(70, 70));

        jButton100.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton100.setText("jButton3");
        jButton100.setContentAreaFilled(false);
        jButton100.setFocusPainted(false);
        jButton100.setMaximumSize(new java.awt.Dimension(70, 70));

        jButton82.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton82.setText("jButton3");
        jButton82.setContentAreaFilled(false);
        jButton82.setFocusPainted(false);
        jButton82.setMaximumSize(new java.awt.Dimension(70, 70));

        jButton84.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton84.setText("jButton3");
        jButton84.setContentAreaFilled(false);
        jButton84.setFocusPainted(false);
        jButton84.setMaximumSize(new java.awt.Dimension(70, 70));

        jButton88.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton88.setText("jButton3");
        jButton88.setContentAreaFilled(false);
        jButton88.setFocusPainted(false);
        jButton88.setMaximumSize(new java.awt.Dimension(70, 70));

        jButton101.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton101.setText("jButton3");
        jButton101.setContentAreaFilled(false);
        jButton101.setFocusPainted(false);
        jButton101.setMaximumSize(new java.awt.Dimension(70, 70));

        jButton94.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton94.setText("jButton3");
        jButton94.setContentAreaFilled(false);
        jButton94.setFocusPainted(false);
        jButton94.setMaximumSize(new java.awt.Dimension(70, 70));

        jButton86.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton86.setText("jButton3");
        jButton86.setContentAreaFilled(false);
        jButton86.setFocusPainted(false);
        jButton86.setMaximumSize(new java.awt.Dimension(70, 70));

        jButton92.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton92.setText("jButton3");
        jButton92.setContentAreaFilled(false);
        jButton92.setFocusPainted(false);
        jButton92.setMaximumSize(new java.awt.Dimension(70, 70));

        jButton91.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton91.setText("jButton3");
        jButton91.setContentAreaFilled(false);
        jButton91.setFocusPainted(false);
        jButton91.setMaximumSize(new java.awt.Dimension(70, 70));

        jButton11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton11.setText("jButton3");
        jButton11.setContentAreaFilled(false);
        jButton11.setFocusPainted(false);
        jButton11.setMaximumSize(new java.awt.Dimension(70, 70));

        jButton98.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton98.setText("jButton3");
        jButton98.setContentAreaFilled(false);
        jButton98.setFocusPainted(false);
        jButton98.setMaximumSize(new java.awt.Dimension(70, 70));

        jButton78.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton78.setText("jButton3");
        jButton78.setContentAreaFilled(false);
        jButton78.setFocusPainted(false);
        jButton78.setMaximumSize(new java.awt.Dimension(70, 70));

        jButton90.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton90.setText("jButton3");
        jButton90.setContentAreaFilled(false);
        jButton90.setFocusPainted(false);
        jButton90.setMaximumSize(new java.awt.Dimension(70, 70));

        jButton77.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton77.setText("jButton3");
        jButton77.setContentAreaFilled(false);
        jButton77.setFocusPainted(false);
        jButton77.setMaximumSize(new java.awt.Dimension(70, 70));

        jButton80.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton80.setText("jButton3");
        jButton80.setContentAreaFilled(false);
        jButton80.setFocusPainted(false);
        jButton80.setMaximumSize(new java.awt.Dimension(70, 70));

        jButton99.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton99.setText("jButton3");
        jButton99.setContentAreaFilled(false);
        jButton99.setFocusPainted(false);
        jButton99.setMaximumSize(new java.awt.Dimension(70, 70));

        jButton10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton10.setText("jButton3");
        jButton10.setContentAreaFilled(false);
        jButton10.setFocusPainted(false);
        jButton10.setMaximumSize(new java.awt.Dimension(70, 70));

        jButton138.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton138.setText("jButton3");
        jButton138.setContentAreaFilled(false);
        jButton138.setFocusPainted(false);
        jButton138.setMaximumSize(new java.awt.Dimension(70, 70));

        jButton139.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton139.setText("jButton3");
        jButton139.setContentAreaFilled(false);
        jButton139.setFocusPainted(false);
        jButton139.setMaximumSize(new java.awt.Dimension(70, 70));

        jButton140.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton140.setText("jButton3");
        jButton140.setContentAreaFilled(false);
        jButton140.setFocusPainted(false);
        jButton140.setMaximumSize(new java.awt.Dimension(70, 70));

        jButton141.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton141.setText("jButton3");
        jButton141.setContentAreaFilled(false);
        jButton141.setFocusPainted(false);
        jButton141.setMaximumSize(new java.awt.Dimension(70, 70));

        jButton142.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton142.setText("jButton3");
        jButton142.setContentAreaFilled(false);
        jButton142.setFocusPainted(false);
        jButton142.setMaximumSize(new java.awt.Dimension(70, 70));

        jButton143.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton143.setText("jButton3");
        jButton143.setContentAreaFilled(false);
        jButton143.setFocusPainted(false);
        jButton143.setMaximumSize(new java.awt.Dimension(70, 70));

        jButton144.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton144.setText("jButton3");
        jButton144.setContentAreaFilled(false);
        jButton144.setFocusPainted(false);
        jButton144.setMaximumSize(new java.awt.Dimension(70, 70));

        jButton145.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton145.setText("jButton3");
        jButton145.setContentAreaFilled(false);
        jButton145.setFocusPainted(false);
        jButton145.setMaximumSize(new java.awt.Dimension(70, 70));

        jButton146.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton146.setText("jButton3");
        jButton146.setContentAreaFilled(false);
        jButton146.setFocusPainted(false);
        jButton146.setMaximumSize(new java.awt.Dimension(70, 70));

        jButton147.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton147.setText("jButton3");
        jButton147.setContentAreaFilled(false);
        jButton147.setFocusPainted(false);
        jButton147.setMaximumSize(new java.awt.Dimension(70, 70));
        jButton147.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton147ActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jPanel2.setLayout(null);

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton3.setText("jButton3");
        jButton3.setContentAreaFilled(false);
        jButton3.setFocusPainted(false);
        jButton3.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton3);
        jButton3.setBounds(60, 0, 60, 60);

        jButton13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton13.setText("jButton3");
        jButton13.setContentAreaFilled(false);
        jButton13.setFocusPainted(false);
        jButton13.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton13);
        jButton13.setBounds(0, 0, 60, 60);

        jButton14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton14.setText("jButton3");
        jButton14.setContentAreaFilled(false);
        jButton14.setFocusPainted(false);
        jButton14.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton14);
        jButton14.setBounds(120, 0, 60, 60);

        jButton15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton15.setText("jButton3");
        jButton15.setContentAreaFilled(false);
        jButton15.setFocusPainted(false);
        jButton15.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton15);
        jButton15.setBounds(180, 0, 60, 60);

        jButton16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton16.setText("jButton3");
        jButton16.setContentAreaFilled(false);
        jButton16.setFocusPainted(false);
        jButton16.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton16);
        jButton16.setBounds(240, 0, 60, 60);

        jButton17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton17.setText("jButton3");
        jButton17.setContentAreaFilled(false);
        jButton17.setFocusPainted(false);
        jButton17.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton17);
        jButton17.setBounds(300, 0, 60, 60);

        jButton18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton18.setText("jButton3");
        jButton18.setContentAreaFilled(false);
        jButton18.setFocusPainted(false);
        jButton18.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton18);
        jButton18.setBounds(360, 0, 60, 60);

        jButton19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton19.setText("jButton3");
        jButton19.setContentAreaFilled(false);
        jButton19.setFocusPainted(false);
        jButton19.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton19);
        jButton19.setBounds(420, 0, 60, 60);

        jButton20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton20.setText("jButton3");
        jButton20.setContentAreaFilled(false);
        jButton20.setFocusPainted(false);
        jButton20.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton20);
        jButton20.setBounds(480, 0, 60, 60);

        jButton21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton21.setText("jButton3");
        jButton21.setContentAreaFilled(false);
        jButton21.setFocusPainted(false);
        jButton21.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton21);
        jButton21.setBounds(540, 0, 60, 60);

        jButton22.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton22.setText("jButton3");
        jButton22.setContentAreaFilled(false);
        jButton22.setFocusPainted(false);
        jButton22.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton22);
        jButton22.setBounds(0, 60, 60, 60);

        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton4.setText("jButton3");
        jButton4.setContentAreaFilled(false);
        jButton4.setFocusPainted(false);
        jButton4.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton4);
        jButton4.setBounds(60, 60, 60, 60);

        jButton23.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton23.setText("jButton3");
        jButton23.setContentAreaFilled(false);
        jButton23.setFocusPainted(false);
        jButton23.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton23);
        jButton23.setBounds(120, 60, 60, 60);

        jButton24.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton24.setText("jButton3");
        jButton24.setContentAreaFilled(false);
        jButton24.setFocusPainted(false);
        jButton24.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton24);
        jButton24.setBounds(180, 60, 60, 60);

        jButton25.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton25.setText("jButton3");
        jButton25.setContentAreaFilled(false);
        jButton25.setFocusPainted(false);
        jButton25.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton25);
        jButton25.setBounds(240, 60, 60, 60);

        jButton26.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton26.setText("jButton3");
        jButton26.setContentAreaFilled(false);
        jButton26.setFocusPainted(false);
        jButton26.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton26);
        jButton26.setBounds(300, 60, 60, 60);

        jButton27.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton27.setText("jButton3");
        jButton27.setContentAreaFilled(false);
        jButton27.setFocusPainted(false);
        jButton27.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton27);
        jButton27.setBounds(360, 60, 60, 60);

        jButton28.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton28.setText("jButton3");
        jButton28.setContentAreaFilled(false);
        jButton28.setFocusPainted(false);
        jButton28.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton28);
        jButton28.setBounds(420, 60, 60, 60);

        jButton29.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton29.setText("jButton3");
        jButton29.setContentAreaFilled(false);
        jButton29.setFocusPainted(false);
        jButton29.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton29);
        jButton29.setBounds(480, 60, 60, 60);

        jButton30.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton30.setText("jButton3");
        jButton30.setContentAreaFilled(false);
        jButton30.setFocusPainted(false);
        jButton30.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton30);
        jButton30.setBounds(540, 60, 60, 60);

        jButton31.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton31.setText("jButton3");
        jButton31.setContentAreaFilled(false);
        jButton31.setFocusPainted(false);
        jButton31.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton31);
        jButton31.setBounds(0, 120, 60, 60);

        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton5.setText("jButton3");
        jButton5.setContentAreaFilled(false);
        jButton5.setFocusPainted(false);
        jButton5.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton5);
        jButton5.setBounds(60, 120, 60, 60);

        jButton32.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton32.setText("jButton3");
        jButton32.setContentAreaFilled(false);
        jButton32.setFocusPainted(false);
        jButton32.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton32);
        jButton32.setBounds(120, 120, 60, 60);

        jButton33.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton33.setText("jButton3");
        jButton33.setContentAreaFilled(false);
        jButton33.setFocusPainted(false);
        jButton33.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton33);
        jButton33.setBounds(180, 120, 60, 60);

        jButton34.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton34.setText("jButton3");
        jButton34.setContentAreaFilled(false);
        jButton34.setFocusPainted(false);
        jButton34.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton34);
        jButton34.setBounds(240, 120, 60, 60);

        jButton35.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton35.setText("jButton3");
        jButton35.setContentAreaFilled(false);
        jButton35.setFocusPainted(false);
        jButton35.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton35);
        jButton35.setBounds(300, 120, 60, 60);

        jButton36.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton36.setText("jButton3");
        jButton36.setContentAreaFilled(false);
        jButton36.setFocusPainted(false);
        jButton36.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton36);
        jButton36.setBounds(360, 120, 60, 60);

        jButton37.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton37.setText("jButton3");
        jButton37.setContentAreaFilled(false);
        jButton37.setFocusPainted(false);
        jButton37.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton37);
        jButton37.setBounds(420, 120, 60, 60);

        jButton38.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton38.setText("jButton3");
        jButton38.setContentAreaFilled(false);
        jButton38.setFocusPainted(false);
        jButton38.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton38);
        jButton38.setBounds(480, 120, 60, 60);

        jButton39.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton39.setText("jButton3");
        jButton39.setContentAreaFilled(false);
        jButton39.setFocusPainted(false);
        jButton39.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton39);
        jButton39.setBounds(540, 120, 60, 60);

        jButton40.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton40.setText("jButton3");
        jButton40.setContentAreaFilled(false);
        jButton40.setFocusPainted(false);
        jButton40.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton40);
        jButton40.setBounds(0, 180, 60, 60);

        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton6.setText("jButton3");
        jButton6.setContentAreaFilled(false);
        jButton6.setFocusPainted(false);
        jButton6.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton6);
        jButton6.setBounds(60, 180, 60, 60);

        jButton41.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton41.setText("jButton3");
        jButton41.setContentAreaFilled(false);
        jButton41.setFocusPainted(false);
        jButton41.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton41);
        jButton41.setBounds(120, 180, 60, 60);

        jButton42.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton42.setText("jButton3");
        jButton42.setContentAreaFilled(false);
        jButton42.setFocusPainted(false);
        jButton42.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton42);
        jButton42.setBounds(180, 180, 60, 60);

        jButton43.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton43.setText("jButton3");
        jButton43.setContentAreaFilled(false);
        jButton43.setFocusPainted(false);
        jButton43.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton43);
        jButton43.setBounds(240, 180, 60, 60);

        jButton44.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton44.setText("jButton3");
        jButton44.setContentAreaFilled(false);
        jButton44.setFocusPainted(false);
        jButton44.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton44);
        jButton44.setBounds(300, 180, 60, 60);

        jButton45.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton45.setText("jButton3");
        jButton45.setContentAreaFilled(false);
        jButton45.setFocusPainted(false);
        jButton45.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton45);
        jButton45.setBounds(360, 180, 60, 60);

        jButton46.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton46.setText("jButton3");
        jButton46.setContentAreaFilled(false);
        jButton46.setFocusPainted(false);
        jButton46.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton46);
        jButton46.setBounds(420, 180, 60, 60);

        jButton47.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton47.setText("jButton3");
        jButton47.setContentAreaFilled(false);
        jButton47.setFocusPainted(false);
        jButton47.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton47);
        jButton47.setBounds(480, 180, 60, 60);

        jButton48.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton48.setText("jButton3");
        jButton48.setContentAreaFilled(false);
        jButton48.setFocusPainted(false);
        jButton48.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton48);
        jButton48.setBounds(540, 180, 60, 60);

        jButton49.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton49.setText("jButton3");
        jButton49.setContentAreaFilled(false);
        jButton49.setFocusPainted(false);
        jButton49.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton49);
        jButton49.setBounds(0, 240, 60, 60);

        jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton7.setText("jButton3");
        jButton7.setContentAreaFilled(false);
        jButton7.setFocusPainted(false);
        jButton7.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton7);
        jButton7.setBounds(60, 240, 60, 60);

        jButton50.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton50.setText("jButton3");
        jButton50.setContentAreaFilled(false);
        jButton50.setFocusPainted(false);
        jButton50.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton50);
        jButton50.setBounds(120, 240, 60, 60);

        jButton51.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton51.setText("jButton3");
        jButton51.setContentAreaFilled(false);
        jButton51.setFocusPainted(false);
        jButton51.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton51);
        jButton51.setBounds(180, 240, 60, 60);

        jButton52.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton52.setText("jButton3");
        jButton52.setContentAreaFilled(false);
        jButton52.setFocusPainted(false);
        jButton52.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton52);
        jButton52.setBounds(240, 240, 60, 60);

        jButton53.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton53.setText("jButton3");
        jButton53.setContentAreaFilled(false);
        jButton53.setFocusPainted(false);
        jButton53.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton53);
        jButton53.setBounds(300, 240, 60, 60);

        jButton54.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton54.setText("jButton3");
        jButton54.setContentAreaFilled(false);
        jButton54.setFocusPainted(false);
        jButton54.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton54);
        jButton54.setBounds(360, 240, 60, 60);

        jButton55.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton55.setText("jButton3");
        jButton55.setContentAreaFilled(false);
        jButton55.setFocusPainted(false);
        jButton55.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton55);
        jButton55.setBounds(420, 240, 60, 60);

        jButton56.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton56.setText("jButton3");
        jButton56.setContentAreaFilled(false);
        jButton56.setFocusPainted(false);
        jButton56.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton56);
        jButton56.setBounds(480, 240, 60, 60);

        jButton57.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton57.setText("jButton3");
        jButton57.setContentAreaFilled(false);
        jButton57.setFocusPainted(false);
        jButton57.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton57);
        jButton57.setBounds(540, 240, 60, 60);

        jButton58.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton58.setText("jButton3");
        jButton58.setContentAreaFilled(false);
        jButton58.setFocusPainted(false);
        jButton58.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton58);
        jButton58.setBounds(0, 300, 60, 60);

        jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton8.setText("jButton3");
        jButton8.setContentAreaFilled(false);
        jButton8.setFocusPainted(false);
        jButton8.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton8);
        jButton8.setBounds(60, 300, 60, 60);

        jButton59.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton59.setText("jButton3");
        jButton59.setContentAreaFilled(false);
        jButton59.setFocusPainted(false);
        jButton59.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton59);
        jButton59.setBounds(120, 300, 60, 60);

        jButton60.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton60.setText("jButton3");
        jButton60.setContentAreaFilled(false);
        jButton60.setFocusPainted(false);
        jButton60.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton60);
        jButton60.setBounds(180, 300, 60, 60);

        jButton61.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton61.setText("jButton3");
        jButton61.setContentAreaFilled(false);
        jButton61.setFocusPainted(false);
        jButton61.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton61);
        jButton61.setBounds(240, 300, 60, 60);

        jButton62.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton62.setText("jButton3");
        jButton62.setContentAreaFilled(false);
        jButton62.setFocusPainted(false);
        jButton62.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton62);
        jButton62.setBounds(300, 300, 60, 60);

        jButton63.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton63.setText("jButton3");
        jButton63.setContentAreaFilled(false);
        jButton63.setFocusPainted(false);
        jButton63.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton63);
        jButton63.setBounds(360, 300, 60, 60);

        jButton64.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton64.setText("jButton3");
        jButton64.setContentAreaFilled(false);
        jButton64.setFocusPainted(false);
        jButton64.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton64);
        jButton64.setBounds(420, 300, 60, 60);

        jButton65.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton65.setText("jButton3");
        jButton65.setContentAreaFilled(false);
        jButton65.setFocusPainted(false);
        jButton65.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton65);
        jButton65.setBounds(480, 300, 60, 60);

        jButton66.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton66.setText("jButton3");
        jButton66.setContentAreaFilled(false);
        jButton66.setFocusPainted(false);
        jButton66.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton66);
        jButton66.setBounds(540, 300, 60, 60);

        jButton67.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton67.setText("jButton3");
        jButton67.setContentAreaFilled(false);
        jButton67.setFocusPainted(false);
        jButton67.setMaximumSize(new java.awt.Dimension(70, 70));
        jButton67.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton67ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton67);
        jButton67.setBounds(0, 360, 60, 60);

        jButton9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton9.setText("jButton3");
        jButton9.setContentAreaFilled(false);
        jButton9.setFocusPainted(false);
        jButton9.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton9);
        jButton9.setBounds(60, 360, 60, 60);

        jButton68.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton68.setText("jButton3");
        jButton68.setContentAreaFilled(false);
        jButton68.setFocusPainted(false);
        jButton68.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton68);
        jButton68.setBounds(120, 360, 60, 60);

        jButton69.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton69.setText("jButton3");
        jButton69.setContentAreaFilled(false);
        jButton69.setFocusPainted(false);
        jButton69.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton69);
        jButton69.setBounds(180, 360, 60, 60);

        jButton70.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton70.setText("jButton3");
        jButton70.setContentAreaFilled(false);
        jButton70.setFocusPainted(false);
        jButton70.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton70);
        jButton70.setBounds(240, 360, 60, 60);

        jButton71.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton71.setText("jButton3");
        jButton71.setContentAreaFilled(false);
        jButton71.setFocusPainted(false);
        jButton71.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton71);
        jButton71.setBounds(300, 360, 60, 60);

        jButton72.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton72.setText("jButton3");
        jButton72.setContentAreaFilled(false);
        jButton72.setFocusPainted(false);
        jButton72.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton72);
        jButton72.setBounds(360, 360, 60, 60);

        jButton73.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton73.setText("jButton3");
        jButton73.setContentAreaFilled(false);
        jButton73.setFocusPainted(false);
        jButton73.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton73);
        jButton73.setBounds(420, 360, 60, 60);

        jButton74.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton74.setText("jButton3");
        jButton74.setContentAreaFilled(false);
        jButton74.setFocusPainted(false);
        jButton74.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton74);
        jButton74.setBounds(480, 360, 60, 60);

        jButton75.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton75.setText("jButton3");
        jButton75.setContentAreaFilled(false);
        jButton75.setFocusPainted(false);
        jButton75.setMaximumSize(new java.awt.Dimension(70, 70));
        jPanel2.add(jButton75);
        jButton75.setBounds(540, 360, 60, 60);

        getContentPane().add(jPanel2);
        jPanel2.setBounds(0, 0, 600, 420);

        jButton103.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton103.setText("jButton3");
        jButton103.setContentAreaFilled(false);
        jButton103.setFocusPainted(false);
        jButton103.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton103);
        jButton103.setBounds(0, 360, 60, 60);

        jButton112.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton112.setText("jButton3");
        jButton112.setContentAreaFilled(false);
        jButton112.setFocusPainted(false);
        jButton112.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton112);
        jButton112.setBounds(540, 360, 60, 60);

        jButton110.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton110.setText("jButton3");
        jButton110.setContentAreaFilled(false);
        jButton110.setFocusPainted(false);
        jButton110.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton110);
        jButton110.setBounds(420, 360, 60, 60);

        jButton108.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton108.setText("jButton3");
        jButton108.setContentAreaFilled(false);
        jButton108.setFocusPainted(false);
        jButton108.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton108);
        jButton108.setBounds(300, 360, 60, 60);

        jButton109.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton109.setText("jButton3");
        jButton109.setContentAreaFilled(false);
        jButton109.setFocusPainted(false);
        jButton109.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton109);
        jButton109.setBounds(360, 360, 60, 60);

        jButton107.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton107.setText("jButton3");
        jButton107.setContentAreaFilled(false);
        jButton107.setFocusPainted(false);
        jButton107.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton107);
        jButton107.setBounds(240, 360, 60, 60);

        jButton104.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton104.setText("jButton3");
        jButton104.setContentAreaFilled(false);
        jButton104.setFocusPainted(false);
        jButton104.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton104);
        jButton104.setBounds(60, 360, 60, 60);

        jButton105.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton105.setText("jButton3");
        jButton105.setContentAreaFilled(false);
        jButton105.setFocusPainted(false);
        jButton105.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton105);
        jButton105.setBounds(120, 360, 60, 60);

        jButton106.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton106.setText("jButton3");
        jButton106.setContentAreaFilled(false);
        jButton106.setFocusPainted(false);
        jButton106.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton106);
        jButton106.setBounds(180, 360, 60, 60);

        jButton111.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton111.setText("jButton3");
        jButton111.setContentAreaFilled(false);
        jButton111.setFocusPainted(false);
        jButton111.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton111);
        jButton111.setBounds(480, 360, 60, 60);

        jButton113.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton113.setText("jButton3");
        jButton113.setContentAreaFilled(false);
        jButton113.setFocusPainted(false);
        jButton113.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton113);
        jButton113.setBounds(0, 360, 60, 60);

        jButton114.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton114.setText("jButton3");
        jButton114.setContentAreaFilled(false);
        jButton114.setFocusPainted(false);
        jButton114.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton114);
        jButton114.setBounds(60, 360, 60, 60);

        jButton115.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton115.setText("jButton3");
        jButton115.setContentAreaFilled(false);
        jButton115.setFocusPainted(false);
        jButton115.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton115);
        jButton115.setBounds(0, 60, 60, 60);

        jButton116.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton116.setText("jButton3");
        jButton116.setContentAreaFilled(false);
        jButton116.setFocusPainted(false);
        jButton116.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton116);
        jButton116.setBounds(0, 360, 60, 60);

        jButton117.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton117.setText("jButton3");
        jButton117.setContentAreaFilled(false);
        jButton117.setFocusPainted(false);
        jButton117.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton117);
        jButton117.setBounds(60, 300, 60, 60);

        jButton118.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton118.setText("jButton3");
        jButton118.setContentAreaFilled(false);
        jButton118.setFocusPainted(false);
        jButton118.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton118);
        jButton118.setBounds(540, 420, 60, 60);

        jButton119.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton119.setText("jButton3");
        jButton119.setContentAreaFilled(false);
        jButton119.setFocusPainted(false);
        jButton119.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton119);
        jButton119.setBounds(480, 420, 60, 60);

        jButton120.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton120.setText("jButton3");
        jButton120.setContentAreaFilled(false);
        jButton120.setFocusPainted(false);
        jButton120.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton120);
        jButton120.setBounds(420, 420, 60, 60);

        jButton121.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton121.setText("jButton3");
        jButton121.setContentAreaFilled(false);
        jButton121.setFocusPainted(false);
        jButton121.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton121);
        jButton121.setBounds(360, 420, 60, 60);

        jButton122.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton122.setText("jButton3");
        jButton122.setContentAreaFilled(false);
        jButton122.setFocusPainted(false);
        jButton122.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton122);
        jButton122.setBounds(300, 420, 60, 60);

        jButton123.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton123.setText("jButton3");
        jButton123.setContentAreaFilled(false);
        jButton123.setFocusPainted(false);
        jButton123.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton123);
        jButton123.setBounds(240, 420, 60, 60);

        jButton124.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton124.setText("jButton3");
        jButton124.setContentAreaFilled(false);
        jButton124.setFocusPainted(false);
        jButton124.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton124);
        jButton124.setBounds(180, 420, 60, 60);

        jButton125.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton125.setText("jButton3");
        jButton125.setContentAreaFilled(false);
        jButton125.setFocusPainted(false);
        jButton125.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton125);
        jButton125.setBounds(120, 420, 60, 60);

        jButton126.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton126.setText("jButton3");
        jButton126.setContentAreaFilled(false);
        jButton126.setFocusPainted(false);
        jButton126.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton126);
        jButton126.setBounds(60, 420, 60, 60);

        jButton127.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton127.setText("jButton3");
        jButton127.setContentAreaFilled(false);
        jButton127.setFocusPainted(false);
        jButton127.setMaximumSize(new java.awt.Dimension(70, 70));
        jButton127.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton127ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton127);
        jButton127.setBounds(0, 420, 60, 60);

        jButton128.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton128.setText("jButton3");
        jButton128.setContentAreaFilled(false);
        jButton128.setFocusPainted(false);
        jButton128.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton128);
        jButton128.setBounds(540, 480, 60, 60);

        jButton129.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton129.setText("jButton3");
        jButton129.setContentAreaFilled(false);
        jButton129.setFocusPainted(false);
        jButton129.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton129);
        jButton129.setBounds(480, 480, 60, 60);

        jButton130.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton130.setText("jButton3");
        jButton130.setContentAreaFilled(false);
        jButton130.setFocusPainted(false);
        jButton130.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton130);
        jButton130.setBounds(420, 480, 60, 60);

        jButton131.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton131.setText("jButton3");
        jButton131.setContentAreaFilled(false);
        jButton131.setFocusPainted(false);
        jButton131.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton131);
        jButton131.setBounds(360, 480, 60, 60);

        jButton132.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton132.setText("jButton3");
        jButton132.setContentAreaFilled(false);
        jButton132.setFocusPainted(false);
        jButton132.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton132);
        jButton132.setBounds(300, 480, 60, 60);

        jButton133.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton133.setText("jButton3");
        jButton133.setContentAreaFilled(false);
        jButton133.setFocusPainted(false);
        jButton133.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton133);
        jButton133.setBounds(240, 480, 60, 60);

        jButton134.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton134.setText("jButton3");
        jButton134.setContentAreaFilled(false);
        jButton134.setFocusPainted(false);
        jButton134.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton134);
        jButton134.setBounds(180, 480, 60, 60);

        jButton135.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton135.setText("jButton3");
        jButton135.setContentAreaFilled(false);
        jButton135.setFocusPainted(false);
        jButton135.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton135);
        jButton135.setBounds(120, 480, 60, 60);

        jButton136.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton136.setText("jButton3");
        jButton136.setContentAreaFilled(false);
        jButton136.setFocusPainted(false);
        jButton136.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton136);
        jButton136.setBounds(60, 480, 60, 60);

        jButton137.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton137.setText("jButton3");
        jButton137.setContentAreaFilled(false);
        jButton137.setFocusPainted(false);
        jButton137.setMaximumSize(new java.awt.Dimension(70, 70));
        jButton137.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton137ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton137);
        jButton137.setBounds(0, 480, 60, 60);

        jButton148.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton148.setText("jButton3");
        jButton148.setContentAreaFilled(false);
        jButton148.setFocusPainted(false);
        jButton148.setMaximumSize(new java.awt.Dimension(70, 70));
        jButton148.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton148ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton148);
        jButton148.setBounds(0, 540, 60, 60);

        jButton149.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton149.setText("jButton3");
        jButton149.setContentAreaFilled(false);
        jButton149.setFocusPainted(false);
        jButton149.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton149);
        jButton149.setBounds(60, 540, 60, 60);

        jButton150.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton150.setText("jButton3");
        jButton150.setContentAreaFilled(false);
        jButton150.setFocusPainted(false);
        jButton150.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton150);
        jButton150.setBounds(120, 540, 60, 60);

        jButton151.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton151.setText("jButton3");
        jButton151.setContentAreaFilled(false);
        jButton151.setFocusPainted(false);
        jButton151.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton151);
        jButton151.setBounds(180, 540, 60, 60);

        jButton152.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton152.setText("jButton3");
        jButton152.setContentAreaFilled(false);
        jButton152.setFocusPainted(false);
        jButton152.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton152);
        jButton152.setBounds(240, 540, 60, 60);

        jButton153.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton153.setText("jButton3");
        jButton153.setContentAreaFilled(false);
        jButton153.setFocusPainted(false);
        jButton153.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton153);
        jButton153.setBounds(300, 540, 60, 60);

        jButton154.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton154.setText("jButton3");
        jButton154.setContentAreaFilled(false);
        jButton154.setFocusPainted(false);
        jButton154.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton154);
        jButton154.setBounds(360, 540, 60, 60);

        jButton155.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton155.setText("jButton3");
        jButton155.setContentAreaFilled(false);
        jButton155.setFocusPainted(false);
        jButton155.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton155);
        jButton155.setBounds(420, 540, 60, 60);

        jButton156.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton156.setText("jButton3");
        jButton156.setContentAreaFilled(false);
        jButton156.setFocusPainted(false);
        jButton156.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton156);
        jButton156.setBounds(480, 540, 60, 60);

        jButton157.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/mar_1.jpg"))); // NOI18N
        jButton157.setText("jButton3");
        jButton157.setContentAreaFilled(false);
        jButton157.setFocusPainted(false);
        jButton157.setMaximumSize(new java.awt.Dimension(70, 70));
        getContentPane().add(jButton157);
        jButton157.setBounds(540, 540, 60, 60);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton67ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton67ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton67ActionPerformed

    private void jButton127ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton127ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton127ActionPerformed

    private void jButton137ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton137ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton137ActionPerformed

    private void jButton147ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton147ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton147ActionPerformed

    private void jButton148ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton148ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton148ActionPerformed

    /**
     * @param args the command line arguments
     */
 

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton100;
    private javax.swing.JButton jButton101;
    private javax.swing.JButton jButton102;
    private javax.swing.JButton jButton103;
    private javax.swing.JButton jButton104;
    private javax.swing.JButton jButton105;
    private javax.swing.JButton jButton106;
    private javax.swing.JButton jButton107;
    private javax.swing.JButton jButton108;
    private javax.swing.JButton jButton109;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton110;
    private javax.swing.JButton jButton111;
    private javax.swing.JButton jButton112;
    private javax.swing.JButton jButton113;
    private javax.swing.JButton jButton114;
    private javax.swing.JButton jButton115;
    private javax.swing.JButton jButton116;
    private javax.swing.JButton jButton117;
    private javax.swing.JButton jButton118;
    private javax.swing.JButton jButton119;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton120;
    private javax.swing.JButton jButton121;
    private javax.swing.JButton jButton122;
    private javax.swing.JButton jButton123;
    private javax.swing.JButton jButton124;
    private javax.swing.JButton jButton125;
    private javax.swing.JButton jButton126;
    private javax.swing.JButton jButton127;
    private javax.swing.JButton jButton128;
    private javax.swing.JButton jButton129;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton130;
    private javax.swing.JButton jButton131;
    private javax.swing.JButton jButton132;
    private javax.swing.JButton jButton133;
    private javax.swing.JButton jButton134;
    private javax.swing.JButton jButton135;
    private javax.swing.JButton jButton136;
    private javax.swing.JButton jButton137;
    private javax.swing.JButton jButton138;
    private javax.swing.JButton jButton139;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton140;
    private javax.swing.JButton jButton141;
    private javax.swing.JButton jButton142;
    private javax.swing.JButton jButton143;
    private javax.swing.JButton jButton144;
    private javax.swing.JButton jButton145;
    private javax.swing.JButton jButton146;
    private javax.swing.JButton jButton147;
    private javax.swing.JButton jButton148;
    private javax.swing.JButton jButton149;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton150;
    private javax.swing.JButton jButton151;
    private javax.swing.JButton jButton152;
    private javax.swing.JButton jButton153;
    private javax.swing.JButton jButton154;
    private javax.swing.JButton jButton155;
    private javax.swing.JButton jButton156;
    private javax.swing.JButton jButton157;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton19;
    private javax.swing.JButton jButton20;
    private javax.swing.JButton jButton21;
    private javax.swing.JButton jButton22;
    private javax.swing.JButton jButton23;
    private javax.swing.JButton jButton24;
    private javax.swing.JButton jButton25;
    private javax.swing.JButton jButton26;
    private javax.swing.JButton jButton27;
    private javax.swing.JButton jButton28;
    private javax.swing.JButton jButton29;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton30;
    private javax.swing.JButton jButton31;
    private javax.swing.JButton jButton32;
    private javax.swing.JButton jButton33;
    private javax.swing.JButton jButton34;
    private javax.swing.JButton jButton35;
    private javax.swing.JButton jButton36;
    private javax.swing.JButton jButton37;
    private javax.swing.JButton jButton38;
    private javax.swing.JButton jButton39;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton40;
    private javax.swing.JButton jButton41;
    private javax.swing.JButton jButton42;
    private javax.swing.JButton jButton43;
    private javax.swing.JButton jButton44;
    private javax.swing.JButton jButton45;
    private javax.swing.JButton jButton46;
    private javax.swing.JButton jButton47;
    private javax.swing.JButton jButton48;
    private javax.swing.JButton jButton49;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton50;
    private javax.swing.JButton jButton51;
    private javax.swing.JButton jButton52;
    private javax.swing.JButton jButton53;
    private javax.swing.JButton jButton54;
    private javax.swing.JButton jButton55;
    private javax.swing.JButton jButton56;
    private javax.swing.JButton jButton57;
    private javax.swing.JButton jButton58;
    private javax.swing.JButton jButton59;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton60;
    private javax.swing.JButton jButton61;
    private javax.swing.JButton jButton62;
    private javax.swing.JButton jButton63;
    private javax.swing.JButton jButton64;
    private javax.swing.JButton jButton65;
    private javax.swing.JButton jButton66;
    private javax.swing.JButton jButton67;
    private javax.swing.JButton jButton68;
    private javax.swing.JButton jButton69;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton70;
    private javax.swing.JButton jButton71;
    private javax.swing.JButton jButton72;
    private javax.swing.JButton jButton73;
    private javax.swing.JButton jButton74;
    private javax.swing.JButton jButton75;
    private javax.swing.JButton jButton76;
    private javax.swing.JButton jButton77;
    private javax.swing.JButton jButton78;
    private javax.swing.JButton jButton79;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton80;
    private javax.swing.JButton jButton81;
    private javax.swing.JButton jButton82;
    private javax.swing.JButton jButton83;
    private javax.swing.JButton jButton84;
    private javax.swing.JButton jButton85;
    private javax.swing.JButton jButton86;
    private javax.swing.JButton jButton87;
    private javax.swing.JButton jButton88;
    private javax.swing.JButton jButton89;
    private javax.swing.JButton jButton9;
    private javax.swing.JButton jButton90;
    private javax.swing.JButton jButton91;
    private javax.swing.JButton jButton92;
    private javax.swing.JButton jButton93;
    private javax.swing.JButton jButton94;
    private javax.swing.JButton jButton95;
    private javax.swing.JButton jButton96;
    private javax.swing.JButton jButton97;
    private javax.swing.JButton jButton98;
    private javax.swing.JButton jButton99;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
